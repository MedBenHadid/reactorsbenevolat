<?php

namespace RefugeeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RefugeeBundle extends Bundle
{
}
